package com.writecraft.taptalk;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.KeyguardManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Path;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.Locale;

public class TapTalkAccessibilityService extends AccessibilityService {
    private static final String CHANNEL_ID = "taptalk_running";
    private static final int NOTIFICATION_ID = 7401;
    private static final long COUNTDOWN_MS = 5000;
    private static final long MAX_RUNTIME_MS = 2L * 60L * 60L * 1000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean receiverRegistered = false;
    private boolean active = false;
    private boolean paused = false;
    private boolean dispatchInProgress = false;
    private long lastAdScanMs = 0;
    private boolean swipe = false;
    private double x1Value, y1Value, x2Value, y2Value;
    private boolean x1Percent, y1Percent, x2Percent, y2Percent;
    private int total = 0;
    private int completed = 0;
    private long intervalMs = 1000;
    private long durationMs = 70;
    private long startedElapsedMs = 0;
    private Runnable pendingTask;

    private final BroadcastReceiver commandReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (intent == null || intent.getAction() == null) return;
            if (MainActivity.ACTION_START.equals(intent.getAction())) {
                startPlan(intent);
            } else if (MainActivity.ACTION_STOP.equals(intent.getAction())) {
                stopAutomation("Stopped by you.");
            } else if (MainActivity.ACTION_PAUSE.equals(intent.getAction())) {
                pauseAutomation("Paused by you. Close the ad or screen manually, then tap RESUME.");
            } else if (MainActivity.ACTION_RESUME.equals(intent.getAction())) {
                resumeAutomation();
            }
        }
    };

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
                .putBoolean("serviceConnected", true).apply();
        if (!receiverRegistered) {
            IntentFilter filter = new IntentFilter();
            filter.addAction(MainActivity.ACTION_START);
            filter.addAction(MainActivity.ACTION_STOP);
            filter.addAction(MainActivity.ACTION_PAUSE);
            filter.addAction(MainActivity.ACTION_RESUME);
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(commandReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(commandReceiver, filter);
            }
            receiverRegistered = true;
        }
        createNotificationChannel();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        // On-device, best-effort ad-screen detection only. Screen text is not uploaded or shared.
        if (!active || paused || event == null) return;
        long now = SystemClock.elapsedRealtime();
        if (now - lastAdScanMs < 650) return;
        lastAdScanMs = now;
        if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                && event.getEventType() != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return;
        StringBuilder visibleText = new StringBuilder();
        if (event.getText() != null) {
            for (CharSequence item : event.getText()) {
                if (item != null) visibleText.append(item).append(' ');
            }
        }
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null) {
                collectNodeText(root, visibleText, 0, new int[]{0});
                root.recycle();
            }
        } catch (Exception ignored) {}
        String screen = visibleText.toString().toLowerCase(Locale.ROOT);
        if (looksLikeAdScreen(screen)) {
            pauseAutomation("Possible ad detected. Please watch and close it yourself, then tap RESUME in the TapTalk notification.");
        }
    }

    private void collectNodeText(AccessibilityNodeInfo node, StringBuilder out, int depth, int[] visited) {
        if (node == null || depth > 18 || visited[0] > 450) return;
        visited[0]++;
        CharSequence text = node.getText();
        if (text != null && text.length() > 0) out.append(text).append(' ');
        CharSequence desc = node.getContentDescription();
        if (desc != null && desc.length() > 0) out.append(desc).append(' ');
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                collectNodeText(child, out, depth + 1, visited);
                child.recycle();
            }
        }
    }

    private boolean looksLikeAdScreen(String screen) {
        String[] markers = {
                "advertisement", "rewarded video", "rewarded ad", "watch an ad",
                "watch ad", "skip ad", "ad loading", "video ad", "sponsored",
                "close ad", "ads by", "advertising"
        };
        for (String marker : markers) if (screen.contains(marker)) return true;
        return false;
    }

    @Override public void onInterrupt() {
        stopAutomation("Android interrupted gesture control.");
    }

    @Override public boolean onUnbind(Intent intent) {
        stopAutomation("Gesture control disconnected.");
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
                .putBoolean("serviceConnected", false).apply();
        return super.onUnbind(intent);
    }

    @Override public void onDestroy() {
        stopAutomation("Gesture control disconnected.");
        if (receiverRegistered) {
            try { unregisterReceiver(commandReceiver); } catch (Exception ignored) {}
            receiverRegistered = false;
        }
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
                .putBoolean("serviceConnected", false).apply();
        super.onDestroy();
    }

    private void startPlan(Intent i) {
        stopAutomation("Replacing previous command.");
        swipe = i.getBooleanExtra(MainActivity.EXTRA_SWIPE, false);
        x1Value = i.getDoubleExtra(MainActivity.EXTRA_X1, 50);
        y1Value = i.getDoubleExtra(MainActivity.EXTRA_Y1, 50);
        x2Value = i.getDoubleExtra(MainActivity.EXTRA_X2, 50);
        y2Value = i.getDoubleExtra(MainActivity.EXTRA_Y2, 50);
        x1Percent = i.getBooleanExtra(MainActivity.EXTRA_X1_PERCENT, true);
        y1Percent = i.getBooleanExtra(MainActivity.EXTRA_Y1_PERCENT, true);
        x2Percent = i.getBooleanExtra(MainActivity.EXTRA_X2_PERCENT, true);
        y2Percent = i.getBooleanExtra(MainActivity.EXTRA_Y2_PERCENT, true);
        total = Math.max(1, Math.min(10000, i.getIntExtra(MainActivity.EXTRA_COUNT, 1)));
        intervalMs = Math.max(250, Math.min(3_600_000, i.getLongExtra(MainActivity.EXTRA_INTERVAL, 1000)));
        durationMs = swipe
                ? Math.max(50, Math.min(10_000, i.getLongExtra(MainActivity.EXTRA_DURATION, 350)))
                : 70;
        completed = 0;
        active = true;
        paused = false;
        dispatchInProgress = false;
        startedElapsedMs = SystemClock.elapsedRealtime();
        setStatus(true, "Starting in 5 seconds. Switch to the target app now.");
        showNotification("Starting in 5 seconds. Switch apps now.");
        pendingTask = this::performNext;
        handler.postDelayed(pendingTask, COUNTDOWN_MS);
    }

    private void performNext() {
        if (!active || paused || dispatchInProgress) return;
        if (completed >= total) {
            stopAutomation("Completed " + completed + " / " + total + " actions.");
            return;
        }
        if (SystemClock.elapsedRealtime() - startedElapsedMs >= MAX_RUNTIME_MS) {
            stopAutomation("Stopped automatically after the 2-hour safety limit.");
            return;
        }
        KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        if (km != null && km.isKeyguardLocked()) {
            stopAutomation("Stopped because the screen is locked.");
            return;
        }

        DisplayMetrics metrics = new DisplayMetrics();
        WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        Display display = wm != null ? wm.getDefaultDisplay() : null;
        if (display != null) display.getRealMetrics(metrics);
        else metrics = getResources().getDisplayMetrics();
        int width = metrics.widthPixels;
        int height = metrics.heightPixels;
        int x1 = resolve(x1Value, x1Percent, width);
        int y1 = resolve(y1Value, y1Percent, height);
        int x2 = resolve(x2Value, x2Percent, width);
        int y2 = resolve(y2Value, y2Percent, height);
        Path path = new Path();
        path.moveTo(x1, y1);
        if (swipe) {
            path.lineTo(x2, y2);
        } else {
            // A zero-distance stroke is interpreted as a tap by Android's gesture dispatcher.
            path.lineTo(x1, y1);
        }
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, durationMs);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
        dispatchInProgress = true;
        boolean accepted = dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gestureDescription) {
                super.onCompleted(gestureDescription);
                if (!active) return;
                dispatchInProgress = false;
                completed++;
                String label = swipe ? "Swipe" : "Tap";
                if (paused) {
                    setStatus(true, "Paused. Close the ad or screen manually, then tap RESUME.");
                    showNotification("Paused. Close the ad manually, then tap RESUME.");
                    return;
                }
                setStatus(true, label + " command running.");
                if (completed >= total) {
                    stopAutomation("Completed " + completed + " / " + total + " actions.");
                    return;
                }
                if (completed % 5 == 0) showNotification(label + " running: " + completed + " / " + total);
                long wait = Math.max(0, intervalMs - durationMs);
                pendingTask = TapTalkAccessibilityService.this::performNext;
                handler.postDelayed(pendingTask, wait);
            }

            @Override public void onCancelled(GestureDescription gestureDescription) {
                super.onCancelled(gestureDescription);
                dispatchInProgress = false;
                if (active) stopAutomation("Gesture cancelled by Android or another touch.");
            }
        }, handler);
        if (!accepted) {
            dispatchInProgress = false;
            stopAutomation("Android rejected the gesture. Check that TapTalk is enabled and try again.");
        }
    }

    private void pauseAutomation(String message) {
        if (!active || paused) return;
        paused = true;
        if (pendingTask != null) {
            handler.removeCallbacks(pendingTask);
            pendingTask = null;
        }
        setStatus(true, message);
        showNotification("Paused: close the ad yourself, then tap RESUME.");
    }

    private void resumeAutomation() {
        if (!active || !paused) return;
        paused = false;
        setStatus(true, "Resumed. Progress: " + completed + " / " + total + ".");
        showNotification("Automation resumed: " + completed + " / " + total);
        pendingTask = this::performNext;
        handler.postDelayed(pendingTask, 500);
    }

    private int resolve(double value, boolean percent, int dimension) {
        double px = percent ? dimension * value / 100.0 : value;
        return (int) Math.round(Math.max(0, Math.min(dimension - 1, px)));
    }

    private void stopAutomation(String message) {
        active = false;
        paused = false;
        dispatchInProgress = false;
        if (pendingTask != null) {
            handler.removeCallbacks(pendingTask);
            pendingTask = null;
        }
        setStatus(false, message);
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(NOTIFICATION_ID);
    }

    private void setStatus(boolean running, String message) {
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
                .putBoolean("running", running)
                .putInt("completed", completed)
                .putInt("total", total)
                .putString("status", message)
                .apply();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "TapTalk automation", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Shows progress and a stop button while TapTalk performs gestures.");
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private void showNotification(String message) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        Intent stopIntent = new Intent(this, StopReceiver.class).setAction(StopReceiver.ACTION_NOTIFICATION_STOP);
        PendingIntent stopPending = PendingIntent.getBroadcast(this, 7402, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent controlIntent = new Intent(this, StopReceiver.class)
                .setAction(paused ? StopReceiver.ACTION_NOTIFICATION_RESUME : StopReceiver.ACTION_NOTIFICATION_PAUSE);
        PendingIntent controlPending = PendingIntent.getBroadcast(this, 7403, controlIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= 26) builder = new Notification.Builder(this, CHANNEL_ID);
        else builder = new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.ic_media_pause)
                .setContentTitle(paused ? "TapTalk paused" : "TapTalk is active")
                .setContentText(message)
                .setOngoing(active)
                .setOnlyAlertOnce(true)
                .addAction(paused ? android.R.drawable.ic_media_play : android.R.drawable.ic_media_pause,
                        paused ? "RESUME" : "PAUSE", controlPending)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "STOP", stopPending);
        nm.notify(NOTIFICATION_ID, builder.build());
    }
}
