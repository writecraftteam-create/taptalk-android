package com.writecraft.taptalk;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Notification controls: pause, resume, or stop explicitly configured gestures. */
public class StopReceiver extends BroadcastReceiver {
    public static final String ACTION_NOTIFICATION_STOP = "com.writecraft.taptalk.NOTIFICATION_STOP";
    public static final String ACTION_NOTIFICATION_PAUSE = "com.writecraft.taptalk.NOTIFICATION_PAUSE";
    public static final String ACTION_NOTIFICATION_RESUME = "com.writecraft.taptalk.NOTIFICATION_RESUME";

    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) return;
        String action = intent.getAction();
        if (ACTION_NOTIFICATION_STOP.equals(action)) {
            context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE).edit()
                    .putBoolean("running", false)
                    .putString("status", "Stop requested from notification.")
                    .apply();
            context.sendBroadcast(new Intent(MainActivity.ACTION_STOP).setPackage(context.getPackageName()));
        } else if (ACTION_NOTIFICATION_PAUSE.equals(action)) {
            context.sendBroadcast(new Intent(MainActivity.ACTION_PAUSE).setPackage(context.getPackageName()));
        } else if (ACTION_NOTIFICATION_RESUME.equals(action)) {
            context.sendBroadcast(new Intent(MainActivity.ACTION_RESUME).setPackage(context.getPackageName()));
        }
    }
}
