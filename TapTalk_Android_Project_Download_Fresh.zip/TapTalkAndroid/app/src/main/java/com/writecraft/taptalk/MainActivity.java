package com.writecraft.taptalk;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.graphics.Typeface;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.content.SharedPreferences;
import android.view.inputmethod.InputMethodManager;

public class MainActivity extends Activity {
    static final String PREFS = "TapTalkPrefs";
    static final String ACTION_START = "com.writecraft.taptalk.START";
    static final String ACTION_STOP = "com.writecraft.taptalk.STOP";
    static final String ACTION_PAUSE = "com.writecraft.taptalk.PAUSE";
    static final String ACTION_RESUME = "com.writecraft.taptalk.RESUME";
    static final String EXTRA_SWIPE = "swipe";
    static final String EXTRA_X1 = "x1";
    static final String EXTRA_Y1 = "y1";
    static final String EXTRA_X2 = "x2";
    static final String EXTRA_Y2 = "y2";
    static final String EXTRA_X1_PERCENT = "x1Percent";
    static final String EXTRA_Y1_PERCENT = "y1Percent";
    static final String EXTRA_X2_PERCENT = "x2Percent";
    static final String EXTRA_Y2_PERCENT = "y2Percent";
    static final String EXTRA_COUNT = "count";
    static final String EXTRA_INTERVAL = "interval";
    static final String EXTRA_DURATION = "duration";

    private EditText commandBox;
    private TextView previewText;
    private TextView statusText;
    private Button startButton;
    private CommandParser.Plan lastPlan;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());

    private final Runnable statusUpdater = new Runnable() {
        @Override public void run() {
            refreshStatus();
            uiHandler.postDelayed(this, 1000);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(23, 45, 70));
        getWindow().setNavigationBarColor(Color.rgb(23, 45, 70));
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildUi();
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        String saved = p.getString("lastCommand", "tap at 50%,75% every 2 seconds for 20 taps");
        commandBox.setText(saved);
        CommandParser.Result result = CommandParser.parse(saved);
        if (result.plan != null) {
            lastPlan = result.plan;
            previewText.setText(result.plan.summary());
        }
        refreshStatus();
    }

    @Override protected void onResume() {
        super.onResume();
        uiHandler.removeCallbacks(statusUpdater);
        uiHandler.post(statusUpdater);
    }

    @Override protected void onPause() {
        super.onPause();
        uiHandler.removeCallbacks(statusUpdater);
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(246, 248, 251));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(20), dp(18), dp(28));
        scroll.addView(root);

        TextView title = text("TapTalk", 30, Color.rgb(23, 45, 70), true);
        root.addView(title, matchWrap());
        TextView subtitle = text("Write a command. Your phone performs the taps or swipes.", 15, Color.rgb(65, 83, 102), false);
        subtitle.setPadding(0, dp(4), 0, dp(14));
        root.addView(subtitle, matchWrap());

        LinearLayout statusCard = card();
        TextView statusHeading = text("STATUS", 12, Color.rgb(9, 135, 125), true);
        statusCard.addView(statusHeading, matchWrap());
        statusText = text("Checking control service…", 14, Color.rgb(23, 45, 70), false);
        statusText.setPadding(0, dp(6), 0, 0);
        statusCard.addView(statusText, matchWrap());
        root.addView(statusCard, matchWrapWithBottom(12));

        TextView commandTitle = text("Your command", 18, Color.rgb(23, 45, 70), true);
        commandTitle.setPadding(0, dp(4), 0, dp(8));
        root.addView(commandTitle, matchWrap());

        commandBox = new EditText(this);
        commandBox.setTextSize(16);
        commandBox.setTextColor(Color.rgb(23, 45, 70));
        commandBox.setHintTextColor(Color.rgb(102, 120, 140));
        commandBox.setHint("Example: tap at 50%,75% every 2 seconds for 100 taps");
        commandBox.setGravity(Gravity.TOP | Gravity.START);
        commandBox.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        commandBox.setMinLines(3);
        commandBox.setMaxLines(6);
        commandBox.setPadding(dp(12), dp(12), dp(12), dp(12));
        commandBox.setBackgroundColor(Color.WHITE);
        commandBox.setSelectAllOnFocus(false);
        root.addView(commandBox, matchWrapWithBottom(10));

        TextView syntax = text("Use percentages (recommended) or pixel coordinates. One action per command.", 13,
                Color.rgb(102, 120, 140), false);
        syntax.setPadding(0, 0, 0, dp(10));
        root.addView(syntax, matchWrap());

        Button parseButton = button("Preview command", Color.rgb(23, 45, 70));
        root.addView(parseButton, matchWrapWithBottom(8));
        parseButton.setOnClickListener(v -> previewCommand());

        startButton = button("START  ·  5-second countdown", Color.rgb(9, 135, 125));
        root.addView(startButton, matchWrapWithBottom(8));
        startButton.setOnClickListener(v -> startCommand());

        Button stopButton = button("STOP NOW", Color.rgb(154, 55, 52));
        root.addView(stopButton, matchWrapWithBottom(14));
        stopButton.setOnClickListener(v -> stopCommand());

        Button accessibilityButton = button("Enable / check gesture control", Color.rgb(230, 245, 242));
        accessibilityButton.setTextColor(Color.rgb(23, 45, 70));
        accessibilityButton.setAllCaps(false);
        root.addView(accessibilityButton, matchWrapWithBottom(18));
        accessibilityButton.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            } catch (Exception e) {
                statusText.setText("Open Android Settings → Accessibility and enable TapTalk gesture control.");
            }
        });

        TextView previewHeading = text("Command preview", 18, Color.rgb(23, 45, 70), true);
        previewHeading.setPadding(0, dp(2), 0, dp(8));
        root.addView(previewHeading, matchWrap());
        LinearLayout previewCard = card();
        previewText = text("Your parsed command will appear here.", 14, Color.rgb(23, 45, 70), false);
        previewText.setLineSpacing(dp(3), 1.0f);
        previewCard.addView(previewText, matchWrap());
        root.addView(previewCard, matchWrapWithBottom(16));

        TextView help = text(
                "EXAMPLES\n" +
                "• tap at 50%,75% every 2 seconds for 100 taps\n" +
                "• tap at center every 1 second for 50 taps\n" +
                "• tap bottom right every 1 second for 20 taps\n" +
                "• tap at 500,1200 every 3 seconds for 20 taps\n" +
                "• swipe up in 400 ms every 2 seconds for 20 times\n" +
                "• swipe from 50%,80% to 50%,30% in 400 ms every 2 seconds for 20 times\n" +
                "• type stop to cancel a running command\n\n" +
                "Percentages are relative to your screen. Pixel positions start at the top-left. " +
                "Use PAUSE or STOP in the notification any time. If readable ad wording is detected, TapTalk pauses; you must watch and close ads yourself, then tap RESUME. Detection is best-effort and may miss ads. Screen text is checked on your phone and is not sent anywhere. " +
                "Commands are limited to 10,000 actions and at most 2 hours.",
                13, Color.rgb(65, 83, 102), false);
        help.setLineSpacing(dp(4), 1.0f);
        root.addView(help, matchWrap());
        setContentView(scroll);
    }

    private void previewCommand() {
        String raw = commandBox.getText().toString().trim();
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (raw.equalsIgnoreCase("stop") || raw.equalsIgnoreCase("cancel") || raw.equalsIgnoreCase("pause")) {
            stopCommand();
            previewText.setText("Stop command sent.");
            return;
        }
        CommandParser.Result result = CommandParser.parse(raw);
        if (result.plan == null) {
            lastPlan = null;
            previewText.setText("I couldn't prepare that command.\n\n" + result.error);
            p.edit().putString("lastCommand", raw).apply();
            return;
        }
        lastPlan = result.plan;
        previewText.setText(result.plan.summary());
        p.edit().putString("lastCommand", raw).apply();
        hideKeyboard();
    }

    private void startCommand() {
        String raw = commandBox.getText().toString().trim();
        if (raw.equalsIgnoreCase("stop") || raw.equalsIgnoreCase("cancel") || raw.equalsIgnoreCase("pause")) {
            stopCommand();
            previewText.setText("Stop command sent.");
            return;
        }
        CommandParser.Result result = CommandParser.parse(raw);
        if (result.plan == null) {
            previewText.setText("Fix the command first.\n\n" + result.error);
            lastPlan = null;
            return;
        }
        lastPlan = result.plan;
        previewText.setText(result.plan.summary());
        if (!isAccessibilityServiceEnabled()) {
            statusText.setText("Gesture control is OFF. Tap 'Enable / check gesture control', enable TapTalk, then return here.");
            try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); } catch (Exception ignored) {}
            return;
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString("lastCommand", raw)
                .putBoolean("running", true)
                .putInt("completed", 0)
                .putInt("total", result.plan.repetitions)
                .putString("status", "Starting in 5 seconds. Switch to the target app now.")
                .apply();
        Intent i = new Intent(ACTION_START).setPackage(getPackageName());
        CommandParser.Plan plan = result.plan;
        i.putExtra(EXTRA_SWIPE, plan.swipe);
        putCoord(i, EXTRA_X1, EXTRA_X1_PERCENT, plan.x1);
        putCoord(i, EXTRA_Y1, EXTRA_Y1_PERCENT, plan.y1);
        if (plan.swipe) {
            putCoord(i, EXTRA_X2, EXTRA_X2_PERCENT, plan.x2);
            putCoord(i, EXTRA_Y2, EXTRA_Y2_PERCENT, plan.y2);
        }
        i.putExtra(EXTRA_COUNT, plan.repetitions);
        i.putExtra(EXTRA_INTERVAL, plan.intervalMs);
        i.putExtra(EXTRA_DURATION, plan.durationMs);
        sendBroadcast(i);
        statusText.setText("Starting in 5 seconds. Switch to the target app now.");
        startButton.setEnabled(false);
        hideKeyboard();
    }

    private void putCoord(Intent i, String valueKey, String percentKey, CommandParser.Coord c) {
        i.putExtra(valueKey, c.value);
        i.putExtra(percentKey, c.percent);
    }

    private void stopCommand() {
        sendBroadcast(new Intent(ACTION_STOP).setPackage(getPackageName()));
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        p.edit().putBoolean("running", false).putString("status", "Stop requested.").apply();
        statusText.setText("Stop requested.");
        startButton.setEnabled(true);
    }

    private void refreshStatus() {
        if (statusText == null) return;
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        boolean enabled = isAccessibilityServiceEnabled();
        boolean running = p.getBoolean("running", false);
        int completed = p.getInt("completed", 0);
        int total = p.getInt("total", 0);
        String savedStatus = p.getString("status", "Ready.");
        if (!enabled) {
            statusText.setText("Gesture control is OFF. Tap the enable button and switch on 'TapTalk gesture control'.");
        } else if (running) {
            statusText.setText(savedStatus + "\nProgress: " + completed + " / " + total);
        } else {
            statusText.setText(savedStatus + "\nGesture control: enabled.");
        }
        startButton.setEnabled(!running);
    }

    private boolean isAccessibilityServiceEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        String shortName = new ComponentName(this, TapTalkAccessibilityService.class).flattenToShortString();
        String fullName = new ComponentName(this, TapTalkAccessibilityService.class).flattenToString();
        for (String entry : enabled.split(":")) {
            if (entry.equalsIgnoreCase(shortName) || entry.equalsIgnoreCase(fullName)) return true;
        }
        return false;
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(commandBox.getWindowToken(), 0);
            commandBox.clearFocus();
        } catch (Exception ignored) {}
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(12), dp(14), dp(12));
        box.setBackgroundColor(Color.WHITE);
        return box;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String label, int background) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(14);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(background));
        b.setMinHeight(dp(48));
        return b;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams matchWrapWithBottom(int bottomDp) {
        LinearLayout.LayoutParams p = matchWrap();
        p.bottomMargin = dp(bottomDp);
        return p;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
