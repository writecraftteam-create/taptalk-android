package com.writecraft.taptalk;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Offline, deterministic parser for user-written tap/swipe commands. */
public final class CommandParser {
    private CommandParser() {}

    private static final String N = "(-?\\d+(?:\\.\\d+)?%?)";
    private static final Pattern XY = Pattern.compile(
            "x\\s*=?\\s*" + N + "\\s*(?:,|\\s+and\\s+|\\s+)y\\s*=?\\s*" + N,
            Pattern.CASE_INSENSITIVE);
    private static final Pattern PAIR = Pattern.compile(N + "\\s*[,/]\\s*" + N);
    private static final Pattern SWIPE_XY = Pattern.compile(
            "from\\s+x\\s*=?\\s*" + N + "\\s+y\\s*=?\\s*" + N
                    + "\\s+to\\s+x\\s*=?\\s*" + N + "\\s+y\\s*=?\\s*" + N,
            Pattern.CASE_INSENSITIVE);
    private static final Pattern SWIPE_PAIR = Pattern.compile(
            "from\\s*\\(?\\s*" + N + "\\s*[,/]\\s*" + N + "\\s*\\)?\\s+to\\s*\\(?\\s*"
                    + N + "\\s*[,/]\\s*" + N + "\\s*\\)?",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern COUNT = Pattern.compile(
            "(?:\\bfor\\b\\s*(\\d+)\\s*(?:times?|taps?|swipes?|actions?)\\b|"
                    + "\\brepeat(?:ing)?\\b\\s*(\\d+)\\s*(?:times?|taps?|swipes?|actions?)?\\b)",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern COUNT_FALLBACK = Pattern.compile(
            "\\b(\\d+)\\s*(?:times|taps|swipes|actions)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern INTERVAL = Pattern.compile(
            "(?:\\bevery\\b|\\beach\\b|\\bat\\s+an?\\s+interval\\s+of\\b)\\s+"
                    + "(\\d+(?:\\.\\d+)?)\\s*(milliseconds?|millis?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m)\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern SWIPE_DURATION = Pattern.compile(
            "(?:\\bin\\b|\\bover\\b|\\blasting\\b|\\bduration(?:\\s+of)?\\b)\\s+"
                    + "(\\d+(?:\\.\\d+)?)\\s*(milliseconds?|millis?|ms|seconds?|secs?|s)\\b",
            Pattern.CASE_INSENSITIVE);

    public static final class Coord {
        public final double value;
        public final boolean percent;

        Coord(double value, boolean percent) {
            this.value = value;
            this.percent = percent;
        }

        static Coord parse(String raw) {
            String s = raw.trim();
            boolean percent = s.endsWith("%");
            if (percent) s = s.substring(0, s.length() - 1);
            double value = Double.parseDouble(s);
            if (value < 0) throw new IllegalArgumentException("Coordinates cannot be negative.");
            if (percent && value > 100) throw new IllegalArgumentException("Percent coordinates must be between 0% and 100%.");
            return new Coord(value, percent);
        }

        public int resolve(int dimension) {
            double pixels = percent ? dimension * value / 100.0 : value;
            return (int) Math.round(Math.max(0, Math.min(dimension - 1, pixels)));
        }

        public String display() {
            if (percent) return trimDouble(value) + "%";
            return trimDouble(value) + " px";
        }
    }

    public static final class Plan {
        public final boolean swipe;
        public final Coord x1;
        public final Coord y1;
        public final Coord x2;
        public final Coord y2;
        public final int repetitions;
        public final long intervalMs;
        public final long durationMs;

        Plan(boolean swipe, Coord x1, Coord y1, Coord x2, Coord y2,
             int repetitions, long intervalMs, long durationMs) {
            this.swipe = swipe;
            this.x1 = x1;
            this.y1 = y1;
            this.x2 = x2;
            this.y2 = y2;
            this.repetitions = repetitions;
            this.intervalMs = intervalMs;
            this.durationMs = durationMs;
        }

        public String summary() {
            StringBuilder b = new StringBuilder();
            if (swipe) {
                b.append("SWIPE from (").append(x1.display()).append(", ").append(y1.display())
                        .append(") to (").append(x2.display()).append(", ").append(y2.display()).append(")");
                b.append("\nSwipe duration: ").append(durationMs).append(" ms");
            } else {
                b.append("TAP at (").append(x1.display()).append(", ").append(y1.display()).append(")");
            }
            b.append("\nRepeat count: ").append(repetitions);
            b.append("\nInterval: ").append(formatInterval(intervalMs));
            b.append("\nEstimated run: about ").append(formatInterval(estimateTotalMs()));
            b.append("\nStarts after a 5-second countdown. You can stop at any time.");
            return b.toString();
        }

        public long estimateTotalMs() {
            return Math.max(0, (long) repetitions * intervalMs);
        }
    }

    public static final class Result {
        public final Plan plan;
        public final String error;
        public final boolean stopCommand;

        private Result(Plan plan, String error, boolean stopCommand) {
            this.plan = plan;
            this.error = error;
            this.stopCommand = stopCommand;
        }

        static Result ok(Plan plan) { return new Result(plan, null, false); }
        static Result error(String error) { return new Result(null, error, false); }
        static Result stop() { return new Result(null, null, true); }
        public boolean isSuccess() { return plan != null || stopCommand; }
    }

    public static Result parse(String rawCommand) {
        if (rawCommand == null || rawCommand.trim().isEmpty()) {
            return Result.error("Write a tap or swipe command first.");
        }
        String command = rawCommand.trim().toLowerCase(Locale.ROOT).replaceAll("[.!]+$", "");
        if (command.matches("^(stop|cancel|pause|stop now|cancel now)$")) return Result.stop();

        boolean swipe = Pattern.compile("\\b(swipe|drag)\\b", Pattern.CASE_INSENSITIVE).matcher(command).find();
        boolean tap = Pattern.compile("\\b(tap|click|press)\\b", Pattern.CASE_INSENSITIVE).matcher(command).find();
        if (!swipe && !tap) return Result.error("Start the command with 'tap' or 'swipe'. Type 'stop' to stop a running command.");
        if (swipe && tap) return Result.error("Use one action per command: either tap or swipe.");

        Coord x1, y1, x2 = null, y2 = null;
        try {
            if (swipe) {
                Matcher m = SWIPE_XY.matcher(command);
                if (m.find()) {
                    x1 = Coord.parse(m.group(1)); y1 = Coord.parse(m.group(2));
                    x2 = Coord.parse(m.group(3)); y2 = Coord.parse(m.group(4));
                } else {
                    m = SWIPE_PAIR.matcher(command);
                    if (m.find()) {
                        x1 = Coord.parse(m.group(1)); y1 = Coord.parse(m.group(2));
                        x2 = Coord.parse(m.group(3)); y2 = Coord.parse(m.group(4));
                    } else {
                        Coord[][] directional = swipePreset(command);
                        if (directional == null) {
                            return Result.error("For a swipe, write 'swipe from 50%,80% to 50%,30%' or use 'swipe up'. Include the duration, interval and repeat count.");
                        }
                        x1 = directional[0][0]; y1 = directional[0][1];
                        x2 = directional[1][0]; y2 = directional[1][1];
                    }
                }
            } else {
                Matcher m = XY.matcher(command);
                if (m.find()) {
                    x1 = Coord.parse(m.group(1)); y1 = Coord.parse(m.group(2));
                } else {
                    m = PAIR.matcher(command);
                    if (m.find()) {
                        x1 = Coord.parse(m.group(1)); y1 = Coord.parse(m.group(2));
                    } else {
                        Coord[] preset = tapPreset(command);
                        if (preset == null) {
                            return Result.error("Choose a screen location such as center, top left, bottom right, or coordinates like 50%,75% or 500,1200.");
                        }
                        x1 = preset[0]; y1 = preset[1];
                    }
                }
            }
        } catch (NumberFormatException ex) {
            return Result.error("I couldn't read one of the coordinates. Try numbers such as 50%,75% or 500,1200.");
        } catch (IllegalArgumentException ex) {
            return Result.error(ex.getMessage());
        }

        Matcher countMatcher = COUNT.matcher(command);
        boolean hasCount = countMatcher.find();
        if (!hasCount) {
            countMatcher = COUNT_FALLBACK.matcher(command);
            hasCount = countMatcher.find();
        }
        if (!hasCount) {
            return Result.error("Tell me how many times to repeat it, for example: 'for 100 taps' or 'repeat 20 times'.");
        }

        int repetitions;
        String countText = countMatcher.group(1) != null ? countMatcher.group(1) : countMatcher.group(2);
        try {
            repetitions = Integer.parseInt(countText);
        } catch (NumberFormatException ex) {
            return Result.error("I couldn't read the repeat count.");
        }
        if (repetitions < 1 || repetitions > 10000) {
            return Result.error("Repeat count must be between 1 and 10,000.");
        }

        long intervalMs = 1000;
        Matcher intervalMatcher = INTERVAL.matcher(command);
        if (intervalMatcher.find()) {
            try {
                intervalMs = toMillis(Double.parseDouble(intervalMatcher.group(1)), intervalMatcher.group(2));
            } catch (RuntimeException ex) {
                return Result.error("I couldn't read the interval. Try 'every 2 seconds' or 'every 500 ms'.");
            }
        } else if (Pattern.compile("\\bevery\\s+(?:one\\s+)?second\\b").matcher(command).find()) {
            intervalMs = 1000;
        } else if (Pattern.compile("\\bevery\\s+half\\s+second\\b").matcher(command).find()) {
            intervalMs = 500;
        }
        if (intervalMs < 250 || intervalMs > 3_600_000) {
            return Result.error("The interval must be between 250 milliseconds and 60 minutes.");
        }

        long durationMs = 70;
        if (swipe) {
            durationMs = 350;
            Matcher durationMatcher = SWIPE_DURATION.matcher(command);
            if (durationMatcher.find()) {
                try {
                    durationMs = toMillis(Double.parseDouble(durationMatcher.group(1)), durationMatcher.group(2));
                } catch (RuntimeException ex) {
                    return Result.error("I couldn't read swipe duration. Try 'in 400 ms'.");
                }
            }
            if (durationMs < 50 || durationMs > 10_000) {
                return Result.error("Swipe duration must be between 50 ms and 10 seconds.");
            }
        }
        if ((double) repetitions * intervalMs > 7_200_000d) {
            return Result.error("This command would run for over 2 hours. Reduce the count or interval.");
        }
        return Result.ok(new Plan(swipe, x1, y1, x2, y2, repetitions, intervalMs, durationMs));
    }


    private static Coord[] tapPreset(String command) {
        boolean top = command.contains("top") || command.contains("upper");
        boolean bottom = command.contains("bottom") || command.contains("lower");
        boolean left = command.contains("left");
        boolean right = command.contains("right");
        if (top && left) return point("5%", "10%");
        if (top && right) return point("95%", "10%");
        if (bottom && left) return point("5%", "90%");
        if (bottom && right) return point("95%", "90%");
        if (top) return point("50%", "10%");
        if (bottom) return point("50%", "90%");
        if (left) return point("5%", "50%");
        if (right) return point("95%", "50%");
        if (command.contains("center") || command.contains("middle")) return point("50%", "50%");
        return null;
    }

    private static Coord[][] swipePreset(String command) {
        if (Pattern.compile("\\bup\\b").matcher(command).find())
            return new Coord[][]{point("50%", "75%"), point("50%", "25%")};
        if (Pattern.compile("\\bdown\\b").matcher(command).find())
            return new Coord[][]{point("50%", "25%"), point("50%", "75%")};
        if (Pattern.compile("\\bleft\\b").matcher(command).find())
            return new Coord[][]{point("75%", "50%"), point("25%", "50%")};
        if (Pattern.compile("\\bright\\b").matcher(command).find())
            return new Coord[][]{point("25%", "50%"), point("75%", "50%")};
        return null;
    }

    private static Coord[] point(String x, String y) {
        return new Coord[]{Coord.parse(x), Coord.parse(y)};
    }

    private static long toMillis(double amount, String unit) {
        String u = unit.toLowerCase(Locale.ROOT);
        double multiplier;
        if (u.startsWith("min") || u.equals("m")) multiplier = 60_000;
        else if (u.startsWith("m")) multiplier = 1;
        else if (u.startsWith("s") || u.startsWith("sec")) multiplier = 1000;
        else throw new IllegalArgumentException("Unknown time unit");
        return Math.round(amount * multiplier);
    }

    private static String trimDouble(double d) {
        if (d == Math.rint(d)) return Long.toString((long) d);
        return Double.toString(d);
    }

    private static String formatInterval(long ms) {
        if (ms < 1000) return ms + " ms";
        if (ms % 60_000 == 0) return (ms / 60_000) + " min";
        if (ms % 1000 == 0) return (ms / 1000) + " sec";
        return String.format(Locale.ROOT, "%.1f sec", ms / 1000.0);
    }
}
