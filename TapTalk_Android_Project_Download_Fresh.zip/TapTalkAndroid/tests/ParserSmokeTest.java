import com.writecraft.taptalk.CommandParser;

public class ParserSmokeTest {
    public static void main(String[] args) {
        String[] commands = {
            "tap at 50%,75% every 2 seconds for 100 taps",
            "tap at center every 1 second for 50 taps",
            "tap at 500,1200 every 3 seconds for 20 taps",
            "swipe from 50%,80% to 50%,30% in 400 ms every 2 seconds for 20 times",
            "swipe from x=50% y=80% to x=50% y=30% in 1 second every 3 seconds repeat 4 times",
            "tap x=50% y=75% every 500 ms repeat 5 times",
            "tap bottom right every 1 second for 3 taps",
            "swipe up in 400 ms every 2 seconds for 10 times"
        };
        for (String command : commands) {
            CommandParser.Result r = CommandParser.parse(command);
            if (!r.isSuccess() || r.plan == null) throw new AssertionError(command + " -> " + r.error);
            System.out.println(command + "\n" + r.plan.summary() + "\n");
        }
        if (!CommandParser.parse("stop").stopCommand) throw new AssertionError("stop command didn't parse");
        if (CommandParser.parse("tap at 50%,75% every 20 ms for 5 taps").isSuccess()) throw new AssertionError("min interval check failed");
        if (CommandParser.parse("tap at center every 1 second for 30 seconds").isSuccess()) throw new AssertionError("duration phrase should require an action count");
    }
}
