# TapTalk — user-commanded Android tap and swipe helper

TapTalk is a small native Android project. Type a command such as:

- `tap at 50%,75% every 2 seconds for 100 taps`
- `tap at center every 1 second for 50 taps`
- `tap bottom right every 1 second for 20 taps`
- `tap at 500,1200 every 3 seconds for 20 taps`
- `swipe up in 400 ms every 2 seconds for 20 times`
- `swipe from 50%,80% to 50%,30% in 400 ms every 2 seconds for 20 times`
- `swipe from x=50% y=80% to x=50% y=30% in 500 ms repeat 30 times`
- `stop`

It parses commands locally without an AI account or network connection. The app itself uses Android's AccessibilityService `dispatchGesture()` API to perform the exact actions requested by the user.

## Safety and limits

- Nothing runs until the user explicitly presses **START**.
- There is a 5-second countdown to switch to the target app.
- The ongoing notification has **PAUSE/RESUME** and **STOP** controls.
- The app stops when the command count is complete, the screen is locked, Android cancels a gesture, or the 2-hour safety limit is reached.
- Repeat count is limited to 10,000; interval to at least 250 ms; swipe duration to 50–10,000 ms.
- Optional ad-screen detection reads accessible screen text locally on your phone and pauses when it finds some common ad labels. It is best-effort, may miss ads or pause on a false match, and does not upload or share screen text. You must watch and close ads yourself; the app does not tap ad-close buttons or simulate ad engagement.
- TapTalk cannot understand whether a tap hit the correct UI control. Users should test with a small count first and never target purchase, payment, delete, or other consequential controls.
- Automated game play may violate a game's or reward offer's rules or result in rewards being denied. Check the offer's terms.

## Build an APK on an Android phone

The build environment used to author this project did not contain the Android SDK or Gradle, so a precompiled APK is not included in this source archive.

One phone-only route is **Code on the Go**, an Android IDE that can open and build native Java/Gradle projects:

1. Install it only from the official project site: https://appdevforall.org/code-on-the-go/
2. Extract this ZIP to a folder named `TapTalkAndroid`.
3. In Code on the Go, choose **Open existing project** and select the extracted `TapTalkAndroid` project folder (the one containing `settings.gradle`).
4. Allow its first-time build-tool setup; it may need several GB of free storage and a Wi-Fi connection.
5. Let Gradle sync, then use the IDE's Build/Run action. Find the generated debug APK under `app/build/outputs/apk/debug/app-debug.apk`.
6. Install the APK and open TapTalk. Tap **Enable / check gesture control**, then enable **TapTalk gesture control** in Android Accessibility settings.
7. Return to TapTalk, test one or two taps first, and then use your command.

Official Code on the Go information: https://github.com/appdevforall/CodeOnTheGo/

## Cloud build workflow

For a repository where the source is uploaded as a ZIP at the repository root, use the companion workflow file `build-apk.yml` supplied alongside the source ZIP. Put that file at `.github/workflows/build-apk.yml`, then run the **Build TapTalk APK** workflow in the repository Actions tab. Download `TapTalk-debug-apk` from the successful run. The workflow expects the ZIP to be named `TapTalk_Android_Project_AdPause.zip`.

## Coordinates

- Percent coordinates use the physical display size, with `(0%,0%)` at the top-left and `(100%,100%)` at the bottom-right.
- Pixel coordinates use physical screen pixels, also from the top-left.
- Test the coordinates on your device. Screen cutouts, navigation bars, game overlays, and orientation changes may affect the target position.

## Project layout

- `app/src/main/java/com/writecraft/taptalk/MainActivity.java` — command UI and controls.
- `CommandParser.java` — offline natural-language pattern parser.
- `TapTalkAccessibilityService.java` — repeats the configured tap or swipe.
- `StopReceiver.java` — notification pause/resume/stop actions.
